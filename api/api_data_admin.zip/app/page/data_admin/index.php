<?php 
require_once('tampil.php');
?>
