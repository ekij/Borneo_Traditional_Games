package com.adamnain.permainantradisional.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

import com.adamnain.permainantradisional.R;

public class jenis_permainan extends AppCompatActivity {
    ImageButton pindah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jenis_permainan);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        final MediaPlayer suaraButton = MediaPlayer.create(this, R.raw.button);

        pindah = (ImageButton) findViewById(R.id.menu1);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu1");
                startActivity(intent);
            }
        });

        pindah = (ImageButton) findViewById(R.id.menu2);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu2");
                startActivity(intent);
            }
        });

        pindah = (ImageButton) findViewById(R.id.menu3);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu3");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.menu4);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu4");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.menu5);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu5");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.menu6);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu6");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.menu7);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu7");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.menu8);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu8");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.menu9);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu9");
                startActivity(intent);
            }
        });

        pindah = (ImageButton) findViewById(R.id.menu10);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, menu.class);
                intent.putExtra("menu", "menu10");
                startActivity(intent);
            }
        });


        pindah = (ImageButton) findViewById(R.id.info);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(jenis_permainan.this, tentang.class);
                intent.putExtra("menu", "menu1");
                startActivity(intent);
            }
        });

        pindah = (ImageButton) findViewById(R.id.kembali);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }
}
