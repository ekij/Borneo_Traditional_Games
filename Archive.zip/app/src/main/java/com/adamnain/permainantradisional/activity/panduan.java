package com.adamnain.permainantradisional.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.Toast;

import com.adamnain.permainantradisional.R;

public class panduan extends AppCompatActivity {
    ImageButton pindah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.panduan);
        final MediaPlayer suaraButton = MediaPlayer.create(this, R.raw.button);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);



        pindah = (ImageButton) findViewById(R.id.info);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(panduan.this, tentang.class);
                startActivity(intent);
            }
        });

        pindah = (ImageButton) findViewById(R.id.kembali);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });




        url = "https://permainantradisional.go-web.my.id/panduan.php";
        webview = (WebView) findViewById(R.id.preview);
        WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        webview.setVisibility(View.GONE);

        if (adaInternet()) {

            final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            progressBar = ProgressDialog.show(panduan.this, "Please Wait", "Loading...");

            webview.setWebViewClient(new WebViewClient() {
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    Log.i(TAG, "Processing..");
                    view.loadUrl(url);
                    return true;
                }

                public void onPageFinished(WebView view, String url) {
                    Log.i(TAG, "Finished.. " + url);
                    if (progressBar.isShowing()) {
                        progressBar.dismiss();
                        webview.setVisibility(View.VISIBLE);

                    }
                }

                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    Log.e(TAG, "Error: " + description);
                    webview.setVisibility(View.GONE);
                    pesan_error_koneksi();
                }
            });



            webview.getSettings().setJavaScriptEnabled(true);
            webview.getSettings().setAllowFileAccess(true);
            webview.setVerticalScrollBarEnabled(true);
            webview.requestFocus(View.FOCUS_DOWN);
            webview.requestFocus(View.FOCUS_UP);
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

            webview.loadUrl(url);
        } else {
            Toast.makeText(panduan.this, "Maaf, Terdapat Error pada Koneksi Internet, Silahkan Cek Koneksi Internet Anda.", Toast.LENGTH_LONG).show();

            finish();
            //pesan_error_koneksi();
        }

    }


    String url;
    private WebView webview;
    private static final String TAG = "Main";
    private ProgressDialog progressBar;


    public void pesan_error_koneksi() {
        webview.setVisibility(View.GONE);
        AlertDialog.Builder BackAlertDialog = new AlertDialog.Builder(panduan.this);
        BackAlertDialog.setTitle("Error..!!");
        BackAlertDialog.setMessage("Maaf, Terdapat Error pada Koneksi Internet, Silahkan Cek Koneksi Internet Anda.");
        BackAlertDialog.setPositiveButton("Oke",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
        BackAlertDialog.show();
    }

    public void onBackPressed() {
        if (webview.canGoBack()) {


            webview.scrollTo(0, 0);

            webview.goBack();
            webview.scrollTo(0, 0);

        } else {

            this.finish();

        }
    }

    private boolean adaInternet() {
        ConnectivityManager koneksi = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return koneksi.getActiveNetworkInfo() != null;
    }

    private WebChromeClient getChromeClient() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setCancelable(false);

        return new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
            }
        };
    }


    @Override
    public void onResume() {
        super.onResume();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    }

    @Override
    public void onPause() {
        super.onPause();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED);
    }



}
