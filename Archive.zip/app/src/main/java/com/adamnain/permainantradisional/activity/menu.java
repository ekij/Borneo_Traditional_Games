package com.adamnain.permainantradisional.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.content.res.AppCompatResources;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.adamnain.permainantradisional.R;

public class menu extends AppCompatActivity {
    ImageButton pindah;
    ImageView tampil;
    ImageView judul;
    String menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        final MediaPlayer suaraButton = MediaPlayer.create(this, R.raw.button);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        tampil = (ImageView) findViewById(R.id.tampil);
        judul = (ImageView) findViewById(R.id.judul);

        Intent intent = getIntent();
        menu = intent.getStringExtra("menu");


        if (menu.equals("menu1")) {
            tampil.setImageResource(R.drawable.tampil1);
            judul.setImageResource(R.drawable.judul1);

        }
        else if (menu.equals("menu2")) {
            tampil.setImageResource(R.drawable.tampil2);
            judul.setImageResource(R.drawable.judul2);
        }
        else if (menu.equals("menu3")) {
            tampil.setImageResource(R.drawable.tampil3);
            judul.setImageResource(R.drawable.judul3);
        }
        else if (menu.equals("menu4")) {
            tampil.setImageResource(R.drawable.tampil4);
            judul.setImageResource(R.drawable.judul4);
        }
        else if (menu.equals("menu5")) {
            tampil.setImageResource(R.drawable.tampil5);
            judul.setImageResource(R.drawable.judul5);
        }
        else if (menu.equals("menu6")) {
            tampil.setImageResource(R.drawable.tampil6);
            judul.setImageResource(R.drawable.judul6);
        }
        else if (menu.equals("menu7")) {
            tampil.setImageResource(R.drawable.tampil7);
            judul.setImageResource(R.drawable.judul7);
        }
        else if (menu.equals("menu8")) {
            tampil.setImageResource(R.drawable.tampil8);
            judul.setImageResource(R.drawable.judul8);
        }
        else if (menu.equals("menu9")) {
            tampil.setImageResource(R.drawable.tampil9);
            judul.setImageResource(R.drawable.judul9);
        }
        else if (menu.equals("menu10")) {
            tampil.setImageResource(R.drawable.tampil10);
            judul.setImageResource(R.drawable.judul10);
        }
        else
        {
            tampil.setImageResource(R.drawable.judul);
        }

        pindah = (ImageButton) findViewById(R.id.tombol1);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(menu.this, menu_detail.class);
                intent.putExtra("halaman", "halaman1");
                intent.putExtra("menu", menu);
                startActivity(intent);

            }
        });


        pindah = (ImageButton) findViewById(R.id.tombol2);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(menu.this, menu_detail.class);
                intent.putExtra("halaman", "halaman2");
                intent.putExtra("menu", menu);
                startActivity(intent);

            }
        });


        pindah = (ImageButton) findViewById(R.id.tombol3);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(menu.this, menu_detail.class);
                intent.putExtra("halaman", "halaman3");
                intent.putExtra("menu", menu);
                startActivity(intent);

            }
        });

        pindah = (ImageButton) findViewById(R.id.tombol4);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(menu.this, menu_detail.class);
                intent.putExtra("halaman", "halaman4");
                intent.putExtra("menu", menu);
                startActivity(intent);

            }
        });




        pindah = (ImageButton) findViewById(R.id.info);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaraButton.start();
                Intent intent = new Intent(menu.this, tentang.class);
                startActivity(intent);
            }
        });

        pindah = (ImageButton) findViewById(R.id.kembali);
        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });





    }

    public void video(View view) {

        Intent intent = getIntent();
        menu = intent.getStringExtra("menu");


        if (menu.equals("menu1")) {

        }
        else if (menu.equals("menu2")) {

        }
        else if (menu.equals("menu3")) {

        }
        else if (menu.equals("menu4")) {

        }
        else if (menu.equals("menu5")) {

        }
        else if (menu.equals("menu6")) {

        }
        else if (menu.equals("menu7")) {

        }
        else if (menu.equals("menu8")) {

        }
        else if (menu.equals("menu9")) {

        }
        else if (menu.equals("menu10")) {

        }
        else {
        }
        final MediaPlayer suaraButton = MediaPlayer.create(this, R.raw.button);
        suaraButton.start();
        Intent intents = new Intent(menu.this, video.class);
        intents.putExtra("menu", menu);
        startActivity(intents);
    }
}
