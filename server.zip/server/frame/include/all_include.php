<?php
function location() { return "frame"; };
include '../../../admin/include/function/enc.php';
include '../../../admin/include/koneksi/koneksi.php';
include '../../../admin/include/settings/settings.php';   
include '../../../admin/include/function/all.php';        
include '../../include/desain/cssjs.php';        
include '../../include/desain/mdb.php';        
include '../../include/content/berita.php';        
include '../../include/content/card.php';        
include '../../include/content/komentar.php';        
include '../../include/content/maps.php';        
include '../../include/content/panduan.php';        
?>