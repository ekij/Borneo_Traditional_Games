<?php
include '../../include/all_include.php';	
panduan(); echo "<br>";
panduan(); echo "<br>";
panduan(); echo "<br>";
panduan(); echo "<br>";
panduan(); echo "<br>"; 
?>
