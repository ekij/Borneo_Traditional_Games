<?php
include '../../include/all_include.php';	
maps("data_lokasi_penyewaan","id_lokasi_lokasi_penyewaan","nama_lokasi","lat","lng","no_telepon","alamat","nama_pengelola","foto");
?>
