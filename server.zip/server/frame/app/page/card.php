<?php
include '../../include/all_include.php';	
cardimage("Informasi Judul","Detail","http://www.aljanh.net/data/archive/img/2107117686.jpeg","blue","btn btn-pink","index.php");
cardgradient("Informasi Judul","Detail tentang ini ada disini","http://www.aljanh.net/data/archive/img/2107117686.jpeg","blue","index.php");
cardblockquote("Informasi Judul","Detail tentang ini ada disini","index.php");
?>


