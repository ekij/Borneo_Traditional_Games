<?php
include '../../include/all_include.php';	
berita("2","data_berita","id_berita","judul","tanggal","foto","isi");
?>
