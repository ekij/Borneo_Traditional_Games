<script>
location.href= 'app/page/';
</script>