<?php
include 'function/enc.php';
include 'koneksi/koneksi.php';
include 'settings/settings.php';
include 'function/all.php';
include 'desain/'.$url_desain;
include 'desain/cssjs.php';
include 'function/script.php';
?>