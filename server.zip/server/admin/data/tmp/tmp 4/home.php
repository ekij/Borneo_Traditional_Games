<br>
<center>
    <h3><?php sambutan(); ?></h3>
    <br>
    <img width="700" src="<?php echo $background; ?>">
    <br>
</center>