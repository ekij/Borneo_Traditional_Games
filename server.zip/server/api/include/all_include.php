<?php
function location() { return "api"; };
include '../../../../admin/include/function/enc.php';
include '../../../../admin/include/koneksi/koneksi.php';
include '../../../../admin/include/settings/settings.php';   
include '../../../../admin/include/function/all.php';        
include '../../../include/function/auth.php';
include '../../../include/function/all.php';
?>